<!DOCTYPE html>
<html>
<head>
	<title>API</title>
</head>
<body>
	<h2>List Api</h2>
	<a href="category/read" style="text-decoration: none;">Cactegory</a>
	<br>
	<a href="product/read" style="text-decoration: none;">product</a>
</body>
</html>